var mongoose = require("mongoose");
//creates a databases called cat_app
mongoose.connect("mongodb://localhost/cat_app");

//creating a scema which basically means that we are defining a pattern so that we will have a structure for the database
var catSchema = new mongoose.Schema({
    name:String,
    age:Number
});

//creating a model/object for the database so that we can access the database through this object
var Cat = mongoose.model("Cat",catSchema);

//creating a new cat 
// var george = new Cat({
//     name:"george",
//     age:5
// });
// george.save(function(err,cat){
//     if(err){
//         console.log("SOMETHING WENT WRONG");
//     }
//     else{
//         console.log("You've just added a cat");
//         console.log(cat);
//     }
// });

Cat.create({
    name:"snow white",
    age:2
},function(err,cat){
    if(err){
        console.log(err);
    }
    else{
        console.log(cat);
    }
});

Cat.find({},function(err,cats){
    if(err){
        console.log("error in finding a cat");
        console.log(err);
    }
    else{
        console.log("all the cats in the database")
        console.log(cats);
    }
});