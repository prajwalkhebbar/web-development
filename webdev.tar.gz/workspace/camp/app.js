var express = require("express");
var app = express();
var bodyParser=require("body-parser");
var mongoose = require("mongoose");
mongoose.connect("mongodb://localhost/campsdb");

var campSchema = new mongoose.Schema({
    name: String,
    image: String,
    description: String
});

var camp = mongoose.model("camp",campSchema);

// camp.create({
//         name:"madikeri camp",
//         image:"http://3.bp.blogspot.com/-gtc8fzXckHo/TrPhsYlA-nI/AAAAAAAAB0k/mZZQjw_6Dx0/s1600/Madikeri+125.jpg",
//         description:"its a very nice place to be in and have a camp.....dont know if the picture is accurate though"
// }, function(err,camp){
//     if(err){
//         console.log("error at creation of camp");
//     }
//     else{
//         console.log("a new camp is added");
//         console.log(camp);
//     }
// });
// var campgrounds=[
//         {name:"mysuru camp",image:"https://images.duckduckgo.com/iu/?u=https%3A%2F%2Ftse2.mm.bing.net%2Fth%3Fid%3DOIP.5Gkiqulr-CxrlVRXydwNYgHaE7%26pid%3D15.1&f=1"},
//         {name:"madikeri camp",image:"http://3.bp.blogspot.com/-gtc8fzXckHo/TrPhsYlA-nI/AAAAAAAAB0k/mZZQjw_6Dx0/s1600/Madikeri+125.jpg"},
//         {name:"barachukki falls camp",image:"https://media-cdn.tripadvisor.com/media/photo-s/06/5d/9b/7b/barachukki-and-gaganachukki.jpg"},
//         {name:"mysuru camp",image:"https://images.duckduckgo.com/iu/?u=https%3A%2F%2Ftse2.mm.bing.net%2Fth%3Fid%3DOIP.5Gkiqulr-CxrlVRXydwNYgHaE7%26pid%3D15.1&f=1"},
//         {name:"madikeri camp",image:"http://3.bp.blogspot.com/-gtc8fzXckHo/TrPhsYlA-nI/AAAAAAAAB0k/mZZQjw_6Dx0/s1600/Madikeri+125.jpg"},
//         {name:"barachukki falls camp",image:"https://media-cdn.tripadvisor.com/media/photo-s/06/5d/9b/7b/barachukki-and-gaganachukki.jpg"}]

app.use(bodyParser.urlencoded({extended:true}));
app.set("view engine","ejs");

app.get("/",function(req,res){
    res.render("home");
});

app.get("/camps",function(req,res){
    // displaying the camps
    camp.find({},function(err, allCamps){
        if(err){
            console.log("err in finding the camps");
        }
        else{
           res.render("index",{campgrounds:allCamps}); 
        }
    });
    
});

app.post("/camps",function(req,res){
    var name=req.body.name;
    var image=req.body.image;
    var desc=req.body.description;
    var newCamp={name:name,image:image,description:desc}
    camp.create(newCamp,function(err, newlyCreated){
       if(err){
           console.log("err in creating the new file");
       } 
       else{
           console.log("added a new camp");
            // redirect
            res.redirect("/camps");
       }
    });
    


});

app.get("/camps/new",function(req, res) {
   res.render("new"); 
});

app.get("/camps/:id",function(req, res) {
    camp.findById(req.params.id,function(err, aCamp){
       if(err){
           console.log("err in geting the id of the camps");
       } 
       else{
          res.render("show",{campground:aCamp});     
       }
    });
});
app.listen(process.env.PORT,process.env.IP,function(){
    console.log("The camp server is running");
});