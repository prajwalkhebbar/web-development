var express = require("express");
var app = express();

app.use(express.static("public"));
//set view engine to ejs
app.set("view engine","ejs");

// "/"-->"Hello there useless"
app.get("/",function(req,res){
   res.render("home"); 
});

app.get("/r/:subredditName",function(req,res){
   var subreddit = req.params.subredditName;
   res.render("file",{sub:subreddit});
});

app.get("/anime",function(req, res) {
   var posts=[
      {title:"One piece is best",author:"Eiichiro Oda"},
      {title:"Naruto is best",author:"Masashi Kishimoto"},
      {title:"Gintama is best",author:"Hideaki Sorachi"}
      ]
   res.render("anime",{posts:posts});
});

app.get("/r/:subredditName/comments/:id/:title",function(req, res) {
   console.log(req.params);
   res.send("welcome to the comments page");
});
// code that makes the servers run
app.listen(process.env.PORT,process.env.IP,function(){
   console.log("the server is running"); 
});