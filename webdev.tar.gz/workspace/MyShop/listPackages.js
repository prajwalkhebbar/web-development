var faker = require("faker");
console.log("============================================ \n Welcome to my shop \n=============================================");
for(var i=0;i<10;i++){
    console.log(faker.fake("{{commerce.color}} {{commerce.productAdjective}} {{commerce.productName}} - ${{commerce.price}}"));
}

// console.log(faker.fake("{{name.lastName}}, {{name.firstName}} {{name.suffix}}"));